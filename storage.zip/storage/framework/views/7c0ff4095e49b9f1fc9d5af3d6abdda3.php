<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('products')); ?>

    </div>
    <section class="products_section section_padding">
        <div class="container">
            <ul class="filter_box flex_item">
                <li>
                    <form action="">
                        <ul class="filter_list">
                            <li>
                                <?php echo e(__('filter_by')); ?>:
                            </li>
                            <li>
                                <ul class="filter_item">
                                    <span class="active_filter"><?php echo e(__('gender')); ?></span>
                                    <div class="filter_buttons">
                                        <button class="btn btn_filter" data-gender="male">
                                            <?php echo e(__('male')); ?>

                                        </button>
                                        <button class="btn btn_filter" data-gender="female">
                                            <?php echo e(__('female')); ?>

                                        </button>
                                        <button class="btn btn_filter" data-gender="unisex">
                                            <?php echo e(__('unisex')); ?>

                                        </button>
                                    </div>
                                </ul>
                            </li>
                            <li>
                                <ul class="filter_item">
                                    <span class="active_filter">
                                        <?php echo e(__('brands')); ?>

                                    </span>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="filter_buttons">
                                            <button class="btn btn_filter" data-brand="<?php echo e($brand->id); ?>">
                                                <?php echo e($brand->name); ?>

                                            </button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <button class="btn filter_submit">
                                <?php echo e(__('submit')); ?>

                            </button>
                        </ul>
                    </form>
                </li>
                <li class="filter_list">
                    <form action="">
                        <ul class="filter_item">
                            <span class="active_filter"><?php echo e(__('sort_by')); ?></span>
                            <div class="filter_buttons">
                                <button class="btn btn_filter" data-gender="male">
                                    <?php echo e(__('male')); ?>

                                </button>
                                <button class="btn btn_filter" data-gender="female">
                                    <?php echo e(__('female')); ?>

                                </button>
                                <button class="btn btn_filter" data-gender="unisex">
                                    <?php echo e(__('unisex')); ?>

                                </button>
                            </div>
                        </ul>
                    </form>
                </li>
            </ul>
            <div class="flex_item gap_30">
                <?php if($products->count()): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w_full w_lg_25">
                            <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['url' => route('products.show', $product->slug),'product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/products/index.blade.php ENDPATH**/ ?>