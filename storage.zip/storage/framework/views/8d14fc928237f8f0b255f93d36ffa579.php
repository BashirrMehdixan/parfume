<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['brand']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['brand']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<a href="<?php echo e(route('brands.show', $brand->slug)); ?>">
    <div class="collection_item"
         data-bg="<?php echo e(asset('storage/'.$brand->image)); ?>">
        <div class="overlay"></div>
        <h5 class="brand_title">
            <?php echo e($brand->name); ?>

        </h5>
    </div>
</a>
<?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/components/brand-card.blade.php ENDPATH**/ ?>