<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('brand', $brand)); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/brands/show.blade.php ENDPATH**/ ?>