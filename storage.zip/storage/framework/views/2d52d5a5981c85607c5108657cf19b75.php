<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('brands')); ?>

    </div>
    <section class="section_padding">
        <div class="container">
            <div class="flex_item">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w_full w_md_50 w_lg_33">
                        <?php if (isset($component)) { $__componentOriginal72d6ffe3779e34b1da25c79d5efe371f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f = $attributes; } ?>
<?php $component = App\View\Components\BrandCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BrandCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brand)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f)): ?>
<?php $attributes = $__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f; ?>
<?php unset($__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72d6ffe3779e34b1da25c79d5efe371f)): ?>
<?php $component = $__componentOriginal72d6ffe3779e34b1da25c79d5efe371f; ?>
<?php unset($__componentOriginal72d6ffe3779e34b1da25c79d5efe371f); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/brands/index.blade.php ENDPATH**/ ?>