<?php $__env->startSection('content'); ?>
    
    <section class="banner_section">
        <div class="banner_glide glide">
            <div class="glide__track" data-glide-el="track">
                <ul class="glide__slides">
                    <?php if($slides->count() > 0): ?>
                        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="glide__slide">
                                <div class="banner_block"
                                     style="background-image: url('<?php echo e(asset('storage/'.$slide->image)); ?>')">
                                    <div class="container">
                                        <div class="flex_item">
                                            <div class="w-full w_lg_66">
                                                <h2 class="banner_title">
                                                    <?php echo e($slide->title); ?>

                                                </h2>
                                                <div class="inner_text">
                                                    <?php echo $slide->description; ?>

                                                </div>
                                                <a href="<?php echo e(route('index')); ?>" class="btn btn_main">
                                                    Shop now
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </section>
    

    
    <section class="about_section section_padding">
        <div class="about_box">
            <div class="overlay"></div>
            <div class="container">
                <div class="flex_item">
                    <div class="w_full w_lg_66 mx-auto text_center">
                        <h4 class="section_title">
                            Welcome to Local Face
                        </h4>
                        <p class="inner_text">
                            Welcome to Local Face Perfumes, where the spirit of victory and triumph come alive through
                            scents that empower
                            and inspire. Our curated collection, aptly named "Victory Scented," is a celebration of
                            success and elegance,
                            designed to unleash your victorious essence. Indulge in the sweet taste of triumph with
                            captivating fragrances
                            that tell the tale of your achievements. At Local Face, we believe that every victory
                            deserves a signature
                            scent, and we are dedicated to providing unforgettable fragrances that elevate your spirit
                            and empower your
                            journey.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    
    <section class="values_section section_padding">
        <div class="flex_item">
            <div class="w_full w_lg_50">
                <div class="section_img">
                    <img src="<?php echo e(asset('front/images/section_img/img-1.png')); ?>" alt="">
                </div>
            </div>
            <div class="w_full w_lg_50">
                <div class="content_box">
                    <h4 class="section_title text_center">
                        Our Values
                    </h4>
                    <p class="inner_text">
                        At Local Face, our perfume retail store is built on a foundation of passion and authenticity. We
                        believe in
                        celebrating the individuality of every customer, providing a diverse collection of scents that
                        resonate with their
                        unique personality and style. Our dedicated team of fragrance enthusiasts is committed to
                        creating a welcoming and
                        inclusive environment, where connections are forged, and inspiration thrives.
                    </p>
                    <p class="inner_text">
                        Embracing sustainability and continuous learning, Local Face strives to be more than just a
                        shopping destination; we
                        are a community that inspires and empowers individuals on their fragrance journey.
                    </p>
                </div>
            </div>
        </div>
    </section>
    

    
    <section class="best_selling section_padding">
        <div class="container">
            <h5 class="section_title text_center">
                Best selling products
            </h5>
            <div class="best_selling glide">
                <div class="glide__track" data-glide-el="track">
                    <ul class="glide__slides">
                        <?php if($bestSell->count() > 0): ?>
                            <?php $__currentLoopData = $bestSell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="glide__slide">
                                    <?php if (isset($component)) { $__componentOriginalecfc721726b8b5798826c96d529d8b59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalecfc721726b8b5798826c96d529d8b59 = $attributes; } ?>
<?php $component = App\View\Components\ProductCard::resolve(['url' => route('products.show', ['cat'=>'perfumes', 'slug'=>$product->slug]),'product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProductCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $attributes = $__attributesOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__attributesOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalecfc721726b8b5798826c96d529d8b59)): ?>
<?php $component = $__componentOriginalecfc721726b8b5798826c96d529d8b59; ?>
<?php unset($__componentOriginalecfc721726b8b5798826c96d529d8b59); ?>
<?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="glide__arrows" data-glide-el="controls">
                    <button class="glide__arrow glide__arrow--left" data-glide-dir="<">
                        <i data-lucide="chevron-left"></i>
                    </button>
                    <button class="glide__arrow glide__arrow--right" data-glide-dir=">">
                        <i data-lucide="chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </section>
    

    <section class="home_collections section_padding">
        <div class="container">
            <h4 class="section_title text_center">
                Our collection
            </h4>
            <div class="flex_item">
                <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="collection_row">
                        <?php if (isset($component)) { $__componentOriginal72d6ffe3779e34b1da25c79d5efe371f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f = $attributes; } ?>
<?php $component = App\View\Components\BrandCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BrandCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($brand)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f)): ?>
<?php $attributes = $__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f; ?>
<?php unset($__attributesOriginal72d6ffe3779e34b1da25c79d5efe371f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72d6ffe3779e34b1da25c79d5efe371f)): ?>
<?php $component = $__componentOriginal72d6ffe3779e34b1da25c79d5efe371f; ?>
<?php unset($__componentOriginal72d6ffe3779e34b1da25c79d5efe371f); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="sale_section">
        <div class="container">
            <div class="sale_item">
                <div class="w_full w_lg_50">
                    <h2 class="banner_title">
                        Perfume Year-End Sale! Up to 50% OFF
                    </h2>
                    <p class="inner_text">
                        Discover an exquisite collection of premium perfumes at unbelievable prices during our exclusive
                        Perfume
                        Sale!
                    </p>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn_main">
                        Know more
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="articles_section">
        <div class="container">
            <h2 class="section_title text_center">
                Latest articles
            </h2>
            <div class="flex_item">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="w_full w_md_50 w_lg_33">
                        <?php if (isset($component)) { $__componentOriginal8f8d2693eac7974db8c30fd690e182fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f8d2693eac7974db8c30fd690e182fd = $attributes; } ?>
<?php $component = App\View\Components\BlogComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BlogComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['blog' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blog)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f8d2693eac7974db8c30fd690e182fd)): ?>
<?php $attributes = $__attributesOriginal8f8d2693eac7974db8c30fd690e182fd; ?>
<?php unset($__attributesOriginal8f8d2693eac7974db8c30fd690e182fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f8d2693eac7974db8c30fd690e182fd)): ?>
<?php $component = $__componentOriginal8f8d2693eac7974db8c30fd690e182fd; ?>
<?php unset($__componentOriginal8f8d2693eac7974db8c30fd690e182fd); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4 class="section_title text_center">
                        There's no blog
                    </h4>
                <?php endif; ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/index.blade.php ENDPATH**/ ?>