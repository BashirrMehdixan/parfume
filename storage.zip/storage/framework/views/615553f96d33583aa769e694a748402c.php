<div class="product_card">
    <div class="thumbnail">
        <a href="<?php echo e($url); ?>">
            <?php if($product->image): ?>
                <img src="<?php echo e(asset('storage/'.$product->image[0])); ?>" alt="<?php echo e($product->name); ?>">
            <?php endif; ?>
        </a>
    </div>
    <div class="card_body">
        <a href="<?php echo e($url); ?>">
            <h5 class="p_title">
                <?php echo e($product->name); ?>

            </h5>
        </a>
        <div class="price_body">
            <div class="p_price">
                <span class="currency">$</span>
                <span><?php echo e($product->price); ?></span>
            </div>
            <span class="quantity <?php echo e(!$product->quantity ? 'd_none' : ''); ?>">
                <?php echo e($product->quantity); ?> ml
            </span>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/components/product-card.blade.php ENDPATH**/ ?>