<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['blog']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['blog']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="blog_card">
    <div class="blog_image">
        <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>">
            <img src="<?php echo e(asset('storage/'.$blog->image[0])); ?>" alt="<?php echo e($blog->title); ?>">
        </a>
    </div>
    <div class="blog_body">
        <h4 class="blog_title">
            <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>">
                <?php echo e($blog->title); ?>

            </a>
        </h4>
        <div class="blog_content">
            <div class="inner_text">
                <?php echo Str::limit($blog->description, 300); ?>

            </div>
            <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>" class="btn btn_main_outline">
                <?php echo e(__('read_more')); ?>

            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/components/blog-component.blade.php ENDPATH**/ ?>