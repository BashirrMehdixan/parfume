<!doctype html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('storage/'.$about->favicon)); ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
          integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/glide/glide.core.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/plugins/glide/glide.theme.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>">
    <title>RT Parfume</title>
</head>
<body>
<header>
    <div class="container">
        <div class="overlay"></div>
        <div class="navbar">
            <a href="<?php echo e(route('index')); ?>" class="logo">
                <img src="<?php echo e(asset('storage/'.$about->logo)); ?>" title="<?php echo e($about->name); ?>" alt="<?php echo e($about->name); ?>">
            </a>
            <nav>
                <ul class="nav-menu">
                    <li class="mobile_header">
                        <div class="logo">
                            <a href="<?php echo e(route('index')); ?>">
                                <img src="<?php echo e(asset('storage/'.$about->logo)); ?>" alt="<?php echo e($about->name); ?>">
                            </a>
                        </div>
                        <button class="btn btn_close">
                            <i data-lucide="circle-x"></i>
                        </button>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('index')); ?>" class="nav-link">
                            <?php echo e(__('home')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('brands.index')); ?>" class="nav-link">
                            <?php echo e(__('brands')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('products.index')); ?>" class="nav-link">
                            <?php echo e(__('perfumes')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('watches.index')); ?>" class="nav-link">
                            <?php echo e(__('watches')); ?>

                        </a>
                    </li>
                </ul>
            </nav>
            <div class="right-nav">
                <div class="lang_box">
                    <button class="btn active_lang">
                        <i data-lucide="languages"></i>
                        <?php echo e(LaravelLocalization::getCurrentLocale()); ?>

                    </button>
                    <ul class="lang_items">
                        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="lang_item">
                                <a rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                   href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode)); ?>">
                                    <?php echo e($properties['native']); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <button class="btn btn_mobile">
                    <i data-lucide="menu"></i>
                </button>
            </div>
        </div>
    </div>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer>
    <div class="container">
        <div class="footer_top">
            <div class="footer_logo">
                <a href="<?php echo e(route('index')); ?>">
                    <img src="<?php echo e(asset('storage/'.$about->logo)); ?>" alt="">
                </a>
            </div>
            <div class="flex_item">
                <div class="w_full w_md_50 w_lg_33">
                    <ul class="footer_widget">
                        <li>
                            <h4 class="footer_title fs_24">
                                Subscribe to Our Newsletter:
                            </h4>
                            <p class="inner_text">
                                Receive Updates on New Arrivals and Special Promotions!
                            </p>
                        </li>
                        <li>
                            <form action="">
                                <input type="text" class="form_control" placeholder="Your email here">
                            </form>
                        </li>
                        <li>
                            <ul class="social_networks">
                                <li class="twitter">
                                    <a href="">
                                        <i data-lucide="twitter"></i>
                                    </a>
                                </li>
                                <li class="facebook">
                                    <a href="">
                                        <i data-lucide="facebook"></i>
                                    </a>
                                </li>
                                <li class="linkedin">
                                    <a href="">
                                        <i data-lucide="linkedin"></i>
                                    </a>
                                </li>
                                <li class="instagram">
                                    <a href="">
                                        <i data-lucide="instagram"></i>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="w_full w_md_50 w_lg_66">
                    <div class="flex_item">
                        <div class="w_full w_md_50 w_lg_25">
                            <div class="footer_widget">
                                <h5 class="footer_title">
                                    <?php echo e(__('brands')); ?>

                                </h5>
                                <ul class="footer_list">
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('brands.show', $brand->slug)); ?>">
                                                <?php echo e($brand->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="w_full w_md_50 w_lg_25">
                            <div class="footer_widget">
                                <h5 class="footer_title">
                                    Shopping
                                </h5>
                                <ul class="footer_list">
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Payments
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Delivery options
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Buyer protection
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="w_full w_md_50 w_lg_25">
                            <div class="footer_widget">
                                <h5 class="footer_title">
                                    Customer care
                                </h5>
                                <ul class="footer_list">
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Help center
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Terms & Conditions
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            Privacy policy
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            returns and refund
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            survey & feedback
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="w_full w_md_50 w_lg_25">
                            <div class="footer_widget">
                                <h5 class="footer_title">
                                    <?php echo e(__('pages')); ?>

                                </h5>
                                <ul class="footer_list">
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            <?php echo e(__('about_us')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('brands.index')); ?>">
                                            <?php echo e(__('brands')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('products.index')); ?>">
                                            <?php echo e(__('perfumes')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('index')); ?>">
                                            <?php echo e(__('contact')); ?>

                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright text_center">
            &copy 2024 RT Parfume Inc. All rights reserved
        </div>
    </div>
</footer>
<script src="https://unpkg.com/lucide@latest"></script>
<script src="<?php echo e(asset('front/plugins/glide/glide.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/slide.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/layout/app.blade.php ENDPATH**/ ?>