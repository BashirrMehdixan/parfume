<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo e(Breadcrumbs::render('product', $product)); ?>

    </div>
    <section class="section_padding">
        <div class="container">
            <div class="flex_item items_center">
                <div class="w_full w_lg_40">
                    <div class="glide detail_glide">
                        <div class="glide__track" data-glide-el="track">
                            <ul class="glide__slides">
                                <?php $__currentLoopData = $product->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="glide__slide">
                                        <img src="<?php echo e(asset('storage/'.$image)); ?>" alt="<?php echo e($product->name); ?>">
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="glide__bullets" data-glide-el="controls[nav]">
                            <?php $__currentLoopData = $product->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button class="glide__bullet" data-glide-dir="=<?php echo e($loop->index); ?>">
                                    <img src="<?php echo e(asset('storage/'.$image)); ?>" alt="<?php echo e($product->name); ?>">
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="w_full w_lg_60">
                    <h4 class="product_title">
                        <?php echo e($product->name); ?>

                    </h4>
                    <div class="inner_text">
                        <?php echo $product->description; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/products/show.blade.php ENDPATH**/ ?>