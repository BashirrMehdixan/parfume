<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="flex_item">
           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bashirr\Desktop\Github\php\rt_parfum\resources\views/pages/blog/index.blade.php ENDPATH**/ ?>